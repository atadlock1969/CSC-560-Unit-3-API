const mongoose = require("mongoose");

const AppSchema = mongoose.Schema({
  message: { type: String, trim:true}, 
  Season: {type: String, trim:true},
  First_Name: { type: String, trim:true},
  Last_Name: { type: String, trim:true},
  Age: { type: Number},
  Games: { type: Number},
  PTS: { type: Number},
  AST: { type: Number},
  FT: { type: Number},
  THP: { type: Number},
  BLK: { type: Number},
  PF: { type: Number},

});

var collectionName = 'Players'
module.exports = mongoose.model("Players", AppSchema, collectionName);