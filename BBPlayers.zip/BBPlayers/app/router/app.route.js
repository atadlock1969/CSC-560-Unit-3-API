module.exports = (app) => {
    const App = require("../controller/app.controller.js");
  
    // Create Player Request
    app.post("/create", App.create);
  
    // Update Player Request    
    app.put("/player/:playerId", App.update);
  
    //Delete Player Request
    app.delete("/player/:playerId", App.delete);

    //Find a specific Player Request (by PlayerID)
    app.get("/player/:playerId", App.findOne);

    //Find all Player Request
    app.get("/get-all", App.findAll);

    // *****  5 Queries Requests   *****
    //Sort Player players by the most 3 Points a game average Request
    app.get("/get-all-sort", App.findAllSort);
    
    //Player with the most points per game Request
    app.get("/high-scorer", App.highScorer);

   //Player with the least number of personal fouls per game Request
    app.get("/least-fouls", App.leastFoul);

   //Number of player who play 50 or more games in a season
    app.get("/fifty-plus", App.fiftyPlus);

   //Players who score 20 or more points per game and average 2 or more Assists per game 
    app.get("/twenty-two", App.twentyTwo);

  };