const { Query } = require("mongoose");
const App = require("../mod/app.model.js");
const limit = 1;

// Create and Save a new Player
exports.create = (req, res) => {
  const player = new App({
    Season: req.body.Season,
    First_Name: req.body.First_Name,
    Last_Name: req.body.Last_Name,
    Age: req.body.Age,
    Games: req.body.Games,
    PTS: req.body.PTS,
    AST: req.body.AST,
    FT: req.body.FT,
    THP: req.body.THP,
    BLK: req.body.BLK,
    PF: req.body.PF,
    
  });
  player
    .save()
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        player:
          err.player || "Some error occurred while creating the Message.",
      });
    });
};

// Retrieve all players from the database.
exports.findAll = (req, res) => {
  App.find()
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        player:
          err.player || "Some error occurred while retrieving players.",
      });
    });
};

// Find a single player with a playerId
exports.findOne = (req, res) => {
  App.findById(req.params.playerId)
    .then((data) => {
      if (!data) {
        return res.status(404).send({
          player: "Player not found with id " + req.params.playerId,
        });
      }
      res.send(data);
    })
    .catch((err) => {
      if (err.kind === "ObjectId") {
        return res.status(404).send({
          player: "Player not found with id " + req.params.playerId,
        });
      }
      return res.status(500).send({
        player: "Error retrieving player with id " + req.params.playerId,
      });
    });
};

// Update a player identified by the playerId in the request
exports.update = (req, res) => {
  App.findByIdAndUpdate(
    req.params.playerId,
    {
      Season: req.body.Season,
      First_Name: req.body.First_Name,
      Last_Name: req.body.Last_Name,
      Age: req.body.Age,
      Games: req.body.Games,
      PTS: req.body.PTS,
      AST: req.body.AST,
      FT: req.body.FT,
      THP: req.body.THP,
      BLK: req.body.BLK,
      PF: req.body.PF,
    },
    { new: true }
  )
    .then((data) => {
      if (!data) {
        return res.status(404).send({
          player: "Player not found with id " + req.params.playerId,
        });
      }
      res.send(data);
    })
    .catch((err) => {
      if (err.kind === "ObjectId") {
        return res.status(404).send({
          player: "Player not found with id " + req.params.playerId,
        });
      }
      return res.status(500).send({
        player: "Error updating player with id " + req.params.playerId,
      });
    });
};

// Delete a player with the specified playerId in the request
exports.delete = (req, res) => {
  App.findByIdAndRemove(req.params.playerId)
    .then((data) => {
      if (!data) {
        return res.status(404).send({
          player: "Player not found with id " + req.params.playerId,
        });
      }
      res.send({ player: "Player deleted successfully!" });
    })
    .catch((err) => {
      if (err.kind === "ObjectId" || err.name === "NotFound") {
        return res.status(404).send({
          player: "Player not found with id " + req.params.playerId,
        });
      }
      return res.status(500).send({
        player: "Could not delete player with id " + req.params.playerId,
      });
    });
};


//5 Queries 
   
    //app.get("/twenty-two", App.twentyTwo);
// Retrieve all players from the database sorted by the most 3pts to the least.
const sort1 = {THP: -1}
exports.findAllSort = (req, res) => {
  App.find().sort(sort1)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        player:
          err.player || "Some error occurred while retrieving players.",
      });
    });
};


// Retrieve Players with the highest points average per game.
const sort2 = {PTS: -1};
exports.highScorer = (req, res) => {
  App.find().sort(sort2).limit(limit)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        player:
          err.player || "Some error occurred while retrieving players.",
      });
    });
};


// Retrieve Players with the least number of personal foul average per game.
const sort3 = {PF: 1};
exports.leastFoul = (req, res) => {
  App.find().sort(sort3).limit(limit)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        player:
          err.player || "Some error occurred while retrieving players.",
      });
    });
};

// Number of Players who played 50 or more games
const query = {"Games": {$gte: 50}};
exports.fiftyPlus = (req, res) => {
  App.countDocuments(query, function(err, play){
    if(err){layers
      res.send({
        player:
          err.player || "Some error occurred while retrieving players.",
      });
    }else{
      res.send({"Number of Players played 50 Games or more":play});
      //res.send(data);
    }
  })
};
 

  //Players who averaged more then 20 points per game and had average of 2 or more Assist per game
  const query2 = {$and:[{"PTS": {$gte: 20}},{"AST": {$gte: 2}}]
   };
exports.twentyTwo = (req, res) => {
  App.find(query2)
  .then((data) => {
    res.send(data);
  })
  .catch((err) => {
    res.status(500).send({
      player:
        err.player || "Some error occurred while retrieving players.",
    });
  });
};
 