
//Importing
const express = require('express');
const bodyParser = require('body-parser');

const mongoose = require('mongoose');



//Connect to Database
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://127.0.0.1/76erBasketballDB', 
    {
      useNewUrlParser: true,
    }
  )
  .then(() => {
    console.log("It is all about the database...Connection no trouble");
  })
  .catch((err) => {
    console.log("The database Could not be had... no connection to the database. Error...", err);
    process.exit();
  });


const app = express();

//middleware
app.use(bodyParser.urlencoded({ extended: true }))

app.use(bodyParser.json())

app.get('/', (req, res) => {
    res.json({"Forest says": "The Server is ruuuuunnningggg"});
});

//Define port
var port = 8080


require('./app/router/app.route.js')(app);

//Listen for connections
app.listen(port, () => {
    console.log(`Server is listening via the party line on port ${port}`);
});